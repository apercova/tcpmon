java -cp ./tcpmon-@tcpmon_version@.jar org.apache.ws.commons.tcpmon.TCPMon $*
